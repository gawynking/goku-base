package cn.com.ptpress.cdm.schema;

public class Test {
}
