CREATE TABLE films
(
    code char(5)
);
INSERT INTO films
VALUES ('movie');